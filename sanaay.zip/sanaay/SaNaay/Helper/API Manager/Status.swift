//
//  Status.swift
//  Tummoc
//
//  Created by Kiran Nayak on 06/01/23.
//

import Foundation

enum Status {
    case loading
    case success
    case error
}
