//
//  PrakritiQuestionCollectionCell.swift
//  SaNaay Wellness
//
//  Created by DEEPAK JAIN on 22/10/23.
//

import UIKit

class PrakritiQuestionCollectionCell: UICollectionViewCell {

    
    @IBOutlet weak var lbl_Question: UILabel!
    @IBOutlet weak var btn_Option1: UIControl!
    @IBOutlet weak var btn_Option2: UIControl!
    @IBOutlet weak var btn_Option3: UIControl!
    @IBOutlet weak var btn_Option4: UIControl!
    @IBOutlet weak var lbl_Option1: UILabel!
    @IBOutlet weak var lbl_Option2: UILabel!
    @IBOutlet weak var lbl_Option3: UILabel!
    @IBOutlet weak var lbl_Option4: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
